<?php
/*
Plugin Name: RewriteRule for HatenaToWordpress
Plugin URI:
Description: はてなブログからWordpressに移行した場合のRewriteRule（有効後に即無効に）
Version: 1.0
Author: ausnichts@imuza.com
Author URI: https://imuza.com/
*/

add_filter('rewrite_rules_array','imz_HatenaRewriteRules');
add_filter('init','flushRules');

// flush_rules()
function flushRules(){
	global $wp_rewrite;
   	$wp_rewrite->flush_rules();
}

// はてなブログからwordpressリライトルール
function imz_HatenaRewriteRules($rules)
{
	$newrules = array();
	$newrules['^entry/([^/]+)$'] = 'index.php?name=$matches[1]';
	$newrules['^entry/([0-9]{4})/([0-9]{2})/([0-9]{2})/([^/]+)$'] = 'index.php?name=$matches[1]-$matches[2]-$matches[3]-$matches[4]';
	$newrules['^entry/([0-9]{8})/([0-9]{10})$'] = 'index.php?name=$matches[1]-$matches[2]';
	return $newrules + $rules;
}
